#include "caffe/layers/ip_yv2_reorg_layer.hpp"
#include <vector>
#include <iostream>

namespace caffe {

template <typename Dtype>
void IPYv2ReorgLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>*>& bottom,
                        const vector<Blob<Dtype>*>& top)
{
   // std::cout << this->layer_param_.ipyv2_reorg_param().stride() << std::endl;
   this->stride_ = this->layer_param_.ipyv2_reorg_param().stride();
}

template <typename Dtype>
void IPYv2ReorgLayer<Dtype>::Reshape(const vector<Blob<Dtype>*>& bottom,
                     const vector<Blob<Dtype>*>& top)
{
    int B = bottom[0]->shape(0);
    int C = bottom[0]->shape(1) * (this->stride_ * this->stride_);
    int H = bottom[0]->shape(2) / this->stride_;
    int W = bottom[0]->shape(3) / this->stride_;
    std::cout << B << " " << C << " " << H << " " << W <<std::endl;

    vector<int> shape(4);
    shape[0] = B;
    shape[1] = C;
    shape[2] = H;
    shape[3] = W;
    top[0]->Reshape(shape);
}

template <typename Dtype>
void IPYv2ReorgLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
                         const vector<Blob<Dtype>*>& top)
{

}

template <typename Dtype>
void IPYv2ReorgLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
                          const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom)
{

}

template <typename Dtype>
void IPYv2ReorgLayer<Dtype>::Forward_gpu(const vector<Blob<Dtype>*>& bottom,
                         const vector<Blob<Dtype>*>& top)
{

}

template <typename Dtype>
void IPYv2ReorgLayer<Dtype>::Backward_gpu(const vector<Blob<Dtype>*>& top,
                          const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom)
{

}

#ifdef CPU_ONLY
STUB_GPU(IPYv2ReorgLayer);
#endif

INSTANTIATE_CLASS(IPYv2ReorgLayer);
REGISTER_LAYER_CLASS(IPYv2Reorg);

}

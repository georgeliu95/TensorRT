#include "caffe/layers/ip_yv2_region_layer.hpp"
#include <vector>

namespace caffe {

template <typename Dtype>
void IPYv2RegionLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>*>& bottom,
                        const vector<Blob<Dtype>*>& top)
{

}

template <typename Dtype>
void IPYv2RegionLayer<Dtype>::Reshape(const vector<Blob<Dtype>*>& bottom,
                     const vector<Blob<Dtype>*>& top)
{
    top[0]->ReshapeLike(*bottom[0]);
}

template <typename Dtype>
void IPYv2RegionLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
                         const vector<Blob<Dtype>*>& top)
{

}

template <typename Dtype>
void IPYv2RegionLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
                          const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom)
{

}

template <typename Dtype>
void IPYv2RegionLayer<Dtype>::Forward_gpu(const vector<Blob<Dtype>*>& bottom,
                         const vector<Blob<Dtype>*>& top)
{

}

template <typename Dtype>
void IPYv2RegionLayer<Dtype>::Backward_gpu(const vector<Blob<Dtype>*>& top,
                          const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom)
{

}

#ifdef CPU_ONLY
STUB_GPU(IPYv2RegionLayer);
#endif

INSTANTIATE_CLASS(IPYv2RegionLayer);
REGISTER_LAYER_CLASS(IPYv2Region);

}
